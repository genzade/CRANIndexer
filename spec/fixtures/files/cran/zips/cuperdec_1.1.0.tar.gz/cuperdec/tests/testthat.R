library(testthat)
library(cuperdec)

test_check("cuperdec")
