# defining global variables
# ugly solution to avoid magrittr NOTE
globalVariables(".")

#' @importFrom rlang .data
NULL

#' @importFrom magrittr "%>%"
#' @importFrom rlang .data
#' @noRd
NULL
